/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;

public class Categoties {
    //global variables
    private String strCategoryID;
    private String strCategoryName = "";
    private String strDescription = "";
    private String strError ="";
    
    Connection conn;
    Statement st;
    ResultSet rs;
    
// constructor - customer id as parameter
public Categoties(String ca){
   strCategoryID = ca;
   
   try
   {
       //initialize database driver
        //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Class.forName("com.mysql.jdbc.Driver");
    }
    catch(Exception e)
    {
        System.out.println(e.toString());
    }

    // call method to get customer info from database
    // and load class variables
    
    getCategoryInfo(ca);
}

private void getCategoryInfo(String cat){
    try
    {
         //create database connection
        //conn = DriverManager.getConnection(
        //"jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
        //Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");
        
        //create statement object
        st = conn.createStatement();
        
        //create result set (executes SQL)
        rs = st.executeQuery("SELECT * FROM categories WHERE CategoryID = '" + cat + "'");
        
        //loop to load class variables from result set
        while(rs.next()){
            strCategoryName = rs.getString("CategoryName");
            strDescription = rs.getString("Description");
        }
        //close connections
        rs.close();
        st.close();
        conn.close();        
    }
    catch(Exception e)
    {
       setError(e.toString());
       System.out.println(e.toString());
    }
}

public String getCatName(){
    return strCategoryName;
}
public void setCatName(String cn){
    strCategoryName = cn;
}
public String getDesc(){
    return strDescription;
}
public void setDesc(String d){
    strDescription = d;
}
public String getError()
    {
        return strError;
    }
public void setError(String e)
    {
        strError = e;
    }
    
public boolean isError()
    {
if(strError.length() > 0){
            return true;
}else
        {
            return false;
        }            
} 
public void updateCategoryInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE categories " +
                    "SET CategoryName = \"" + getCatName()+ "\", " +
                    "Description = \"" + getDesc()+ "\" " +
                    "WHERE CategoryID = '" + strCategoryID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }

    public void insertNewCategory()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO categories(CategoryID) " +
                    "VALUES(" + "DEFAULT"  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }

    public void deleteCategory()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM categories " +
                    "WHERE CategoryID = '" + strCategoryID  + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }

}
