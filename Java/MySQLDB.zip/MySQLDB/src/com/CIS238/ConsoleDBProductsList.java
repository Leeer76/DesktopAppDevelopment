/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

/**
 *
 * @author el51909
 */
public class ConsoleDBProductsList {
    public static void main(String args[])
    {
        // create a new customer list object
        ProductsList myList = new ProductsList();

        // print a heading
        System.out.println("Customer List - " + myList.getProductList().getSize());

        // loop to print customer id list
        for(int i=0; i<myList.getProductList().getSize(); i++)
        {
            //print a line number
            System.out.print((i+1) + ": ");
            //print the customer id
            System.out.println(myList.getProductList().getElementAt(i).toString());
        }
    } 
    
}
