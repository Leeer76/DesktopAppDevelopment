/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author EL51909
 */
public class Orders {
     // class variables (global)
    private int strOrderID;
    private String strCustomerID = "";
    private String strEmployeeID = "";
    private String strOrderDate = "";
    private String strShipVia = "";
    private String strShipName = "";
    private String strShipAddress = "";
    private String strShipCity = "";
    private String strShipRegion = "";
    private String strShipPostCode = "";
    private String strShipCountry = "";
    private String strError = "";

    Connection conn;
    Statement st;
    ResultSet rs;

    // constructor - order id as parameter
    public Orders(int o)
    {
        // load private variable
        strOrderID = o;

        // initialize database objects
        try
        {
            //initialize database driver
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }

        // call method to get order info from database
        // and load class variables
        getOrderInfo(o);
    }

    private void getOrderInfo(int order)
    {
        try
        {
            //create database connection
//            conn = DriverManager.getConnection(
//                    "jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
//            Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            rs = st.executeQuery("SELECT * FROM orders WHERE OrderID = '" + order + "'");

            //loop to load class variables from result set
            while(rs.next())
            {
                strCustomerID = rs.getString("CustomerID");
                strEmployeeID = rs.getString("EmployeeID");
                strOrderDate = rs.getString("OrderDate");
                strShipVia = rs.getString("ShipVia");
                strShipName = rs.getString("ShipName");
                strShipAddress = rs.getString("ShipAddress");
                strShipCity = rs.getString("ShipCity");
                strShipRegion = rs.getString("ShipRegion");
                strShipPostCode = rs.getString("ShipPostalCode");
                strShipCountry = rs.getString("ShipCountry");
            }

            //close stuff
            rs.close();
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

    }

    public String getCustomerID()
    {
        return strCustomerID;
    }
    public void setCustomerID(String cid)
    {
        strCustomerID = cid;
    }
    public String getEmployeeID(){
        return strEmployeeID;
    }
    public void setEmployeeID(String eid){
        strEmployeeID = eid;
    }
    public String getOrderDate(){
        return strOrderDate;
    }
    public void setOrderDate(String od){
        strOrderDate = od;
    }
    public String getShipVia(){
        return strShipVia;
    }
    public void setShipVia(String sv){
        strShipVia = sv;
    }
    public String getShipName(){
        return strShipName;
    }
    public void setShipName(String sn){
        strShipName = sn;
    }
    public String getShipAddress(){
        return strShipAddress;
    }
    public void setShipAddress(String sa){
        strShipAddress = sa;
    }
    public String getShipCity(){
        return strShipCity;
    }
    public void setShipCity(String sc){
        strShipCity = sc;
    }
    public String getShipRegion(){
        return strShipRegion;
    }
    public void setShipRegion(String sr){
        strShipRegion = sr;
    }
    public String getShipPostalCode(){
        return strShipPostCode;
    }
    public void setShipPostalCode(String spc){
        strShipPostCode = spc;
    }
    public String getShipCountry(){
        return strShipCountry;
    }
    public void setShipCountry(String scty){
        strShipCountry = scty;
    }
    public String getError()
    {
        return strError;
    }
    public void setError(String e)
    {
        strError = e;
    }
    
    public boolean isError()
    {
        if(strError.length() > 0){
            return true;
        }else{
            return false;
        }
    }
    
     public void updateOrdersInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE orders " +
                    "SET CustomerID = \"" + getCustomerID() + "\", " +
                    "EmployeeID = '" + getEmployeeID() + "', " +
                    "OrderDate = '" + getOrderDate() + "', " +
                    "ShipVia = '" + getShipVia() + "', " +
                    "ShipName = '" + getShipName() + "', " +
                    "ShipAddress = '" + getShipAddress() + "', " +
                    "ShipCity = '" + getShipCity() + "', " +
                    "ShipRegion = '" + getShipRegion() + "', " +
                    "ShipPostalCode = '" + getShipPostalCode() + "', " +
                    "ShipCountry = '" + getShipCountry() + "' " +
                    "WHERE OrderID = '" + strOrderID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     
     public void insertNewOrder()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO orders(OrderID) " +
                    "VALUES(" + "DEFAULT"  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
public void deleteOrder()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM orders " +
                    "WHERE OrderID = '" + strOrderID  + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
}
