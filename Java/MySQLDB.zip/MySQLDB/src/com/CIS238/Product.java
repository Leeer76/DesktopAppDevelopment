/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.CIS238;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author ARMSTROD
 */
public class Product {

    // class variables (global)
    private int strProductID;
    private String strProductName = "";
    private String strSupplierID = "";
    private String strCategoryID = "";
    private String strQuantityperUnit = "";
    private String strUnitPrice = "";
    private String strUnitsInStock = "";
    private String strUnitsOnOrder = "";
    private String strReorderLevel = "";
    private String strDiscontinued = "";
    private String strError = "";

    Connection conn;
    Statement st;
    ResultSet rs;

    // constructor - product id as parameter
    public Product(int c)
    {
        // load private variable
        strProductID = c;

        // initialize database objects
        try
        {
            //initialize database driver
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }

        // call method to get product info from database
        // and load class variables
        getProductInfo(c);
    }

    private void getProductInfo(int prod)
    {
        try
        {
            //create database connection
//            conn = DriverManager.getConnection(
//                    "jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
//            Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            rs = st.executeQuery("SELECT * FROM products WHERE ProductID = '" + prod + "'");

            //loop to load class variables from result set
            while(rs.next())
            {
                strProductName = rs.getString("ProductName");
                strSupplierID = rs.getString("SupplierID");
                strCategoryID = rs.getString("CategoryID");
                strQuantityperUnit = rs.getString("QuantityPerUnit");
                strUnitPrice = rs.getString("UnitPrice");
                strUnitsInStock = rs.getString("UnitsInStock");
                strUnitsOnOrder = rs.getString("UnitsOnOrder");
                strReorderLevel = rs.getString("ReorderLevel");
                strDiscontinued = rs.getString("Discontinued");
            }

            //close stuff
            rs.close();
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

    }

    public String getProductName()
    {
        return strProductName;
    }
    public void setProductName(String pn)
    {
        strProductName = pn;
    }

    public String getSupplierID()
    {
        return strSupplierID;
    }
    public void setSupplierID(String si)
    {
        strSupplierID = si;
    }

    public String getCategoryID()
    {
        return strCategoryID;
    }
    public void setCategoryID(String ci)
    {
        strCategoryID = ci;
    }

    public String getQuantityUnit()
    {
        return strQuantityperUnit;
    }
    public void setQuantityUnit(String qu)
    {
        strQuantityperUnit = qu;
    }

    public String getUnitPrice()
    {
        return strUnitPrice;
    }
    public void setUnitPrice(String up)
    {
        strUnitPrice = up;
    }

    public String getInStock()
    {
        return strUnitsInStock;
    }
    public void setInStock(String is)
    {
        strUnitsInStock = is;
    }

    public String getOnOrder()
    {
        return strUnitsOnOrder;
    }
    public void setOnOrder(String oo)
    {
        strUnitsOnOrder = oo;
    }

    public String getReorderLevel()
    {
        return strReorderLevel;
    }
    public void setReorderLevel(String rl)
    {
        strReorderLevel = rl;
    }
    public String getDiscontinued()
    {
        return strDiscontinued;
    }
    public void setDiscontinued(String d)
    {
        strDiscontinued = d;
    }
    public String getError()
    {
        return strError;
    }
    public void setError(String e)
    {
        strError = e;
    }
    
    public boolean isError()
    {
        if(strError.length() > 0){
            return true;
        }else{
            return false;
        }
    }
    
     public void updateProductsInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE Products " +
                    "SET ProductName = \"" + getProductName()+ "\", " +
                    "QuantityPerUnit = '" + getQuantityUnit()+ "', " +
                    "UnitPrice = '" + getUnitPrice() + "', " +
                    "UnitsInStock = '" + getInStock()+ "', " +
                    "UnitsOnOrder = '" + getOnOrder() + "' " +
                    "WHERE ProductID = '" + strProductID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     
     public void insertNewProduct()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO Products(ProductID) " +
                    "VALUES(" + "DEFAULT"  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
public void deleteProduct()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM Products " +
                    "WHERE ProductID = '" + strProductID  + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
}

