/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author EL51909
 */
public class Shipper {
     // class variables (global)
    private int strShipperID;
    private String strCompanyName = "";
    private String strPhone = "";
    private String strError = "";

    Connection conn;
    Statement st;
    ResultSet rs;

    // constructor - Shipper id as parameter
    public Shipper(int s)
    {
        // load private variable
        strShipperID = s;

        // initialize database objects
        try
        {
            //initialize database driver
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }

        // call method to get shipper info from database
        // and load class variables
        getShipperInfo(s);
    }

    private void getShipperInfo(int ship)
    {
        try
        {
            //create database connection
//            conn = DriverManager.getConnection(
//                    "jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
//            Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            rs = st.executeQuery("SELECT * FROM shippers WHERE ShipperID = '" + ship + "'");

            //loop to load class variables from result set
            while(rs.next())
            {
                strCompanyName = rs.getString("CompanyName");
                strPhone = rs.getString("Phone");
            }

            //close stuff
            rs.close();
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

    }

    public String getCompanyName()
    {
        return strCompanyName;
    }
    public void setCompanyName(String cn)
    {
        strCompanyName = cn;
    }

    public String getPhone()
    {
        return strPhone;
    }
    public void setPhone(String p)
    {
        strPhone = p;
    }
    public String getError()
    {
        return strError;
    }
    public void setError(String e)
    {
        strError = e;
    }
    
    public boolean isError()
    {
        if(strError.length() > 0){
            return true;
        }else{
            return false;
        }
    }
    
     public void updateShippersInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE Shippers " +
                    "SET CompanyName = \"" + getCompanyName() + "\", " +
                    "Phone = '" + getPhone() + "' " +
                    "WHERE ShipperID = '" + strShipperID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     
     public void insertNewShipper()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO shippers(ShipperID) " +
                    "VALUES(" + "DEFAULT"  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
public void deleteShipper()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM shippers " +
                    "WHERE ShipperID = '" + strShipperID + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
}
