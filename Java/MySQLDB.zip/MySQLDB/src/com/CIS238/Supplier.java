/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author EL51909
 */
public class Supplier {
     // class variables (global)
    private int strSupplierID;
    private String strCompName = "";
    private String strContName = "";
    private String strAddress = "";
    private String strCity = "";
    private String strRegion = "";
    private String strPostCode = "";
    private String strCountry = "";
    private String strPhone = "";;
    private String strError = "";

    Connection conn;
    Statement st;
    ResultSet rs;

    // constructor - product id as parameter
    public Supplier(int s)
    {
        // load private variable
        strSupplierID = s;

        // initialize database objects
        try
        {
            //initialize database driver
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }

        // call method to get product info from database
        // and load class variables
        getSupplierInfo(s);
    }

    private void getSupplierInfo(int sup)
    {
        try
        {
            //create database connection
//            conn = DriverManager.getConnection(
//                    "jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
//            Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            rs = st.executeQuery("SELECT * FROM suppliers WHERE SupplierID = '" + sup + "'");

            //loop to load class variables from result set
            while(rs.next())
            {
                strCompName = rs.getString("CompanyName");
                strContName = rs.getString("ContactName");
                strAddress = rs.getString("Address");
                strCity = rs.getString("City");
                strRegion = rs.getString("Region");
                strPostCode = rs.getString("PostalCode");
                strCountry = rs.getString("Country");
                strPhone = rs.getString("Phone");
            }

            //close stuff
            rs.close();
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

    }

    public String getCompanyName()
    {
        return strCompName;
    }
    public void setCompanyName(String cn)
    {
        strCompName = cn;
    }

    public String getContactName()
    {
        return strContName;
    }
    public void setContactName(String ctn)
    {
        strContName = ctn;
    }

    public String getAddress()
    {
        return strAddress;
    }
    public void setAddress(String a)
    {
        strAddress = a;
    }

    public String getCity()
    {
        return strCity;
    }
    public void setCity(String cty)
    {
        strCity = cty;
    }

    public String getRegion()
    {
        return strRegion;
    }
    public void setRegion(String r)
    {
        strRegion = r;
    }

    public String getPostalCode()
    {
        return strPostCode;
    }
    public void setPostalCode(String pc)
    {
        strPostCode = pc;
    }

    public String getCountry()
    {
        return strCountry;
    }
    public void setCountry(String cou)
    {
        strCountry = cou;
    }

    public String getPhone()
    {
        return strPhone;
    }
    public void setPhone(String p)
    {
        strPhone = p;
    }
    public String getError()
    {
        return strError;
    }
    public void setError(String e)
    {
        strError = e;
    }
    
    public boolean isError()
    {
        if(strError.length() > 0){
            return true;
        }else{
            return false;
        }
    }
    
     public void updateSupplierInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE suppliers " +
                    "SET CompanyName = \"" + getCompanyName() + "\", " +
                    "ContactName = \"" + getContactName() + "\", " +
                    "Address = '" + getAddress() + "', " +
                    "City = '" + getCity() + "', " +
                    "Region = '" + getRegion() + "', " +
                    "PostalCode = '" + getPostalCode() + "', " +
                    "Country = '" + getCountry() + "', " +
                    "Phone = '" + getPhone() + "' " +
                    "WHERE SupplierID = '" + strSupplierID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     
     public void insertNewSupplier()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO suppliers(SupplierID) " +
                    "VALUES(" + "DEFAULT"  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
public void deleteSupplier()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM suppliers " +
                    "WHERE SupplierID = '" + strSupplierID  + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
}
