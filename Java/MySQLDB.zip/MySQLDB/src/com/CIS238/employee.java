/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CIS238;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author el51909
 */
public class employee {
    // class variables (global)
    private String strEmployeeID = "";
    private String strLastName = "";
    private String strFirstName = "";
    private String strTitle = "";
    private String strTitleCourtesy = "";
    private String strAddress = "";
    private String strCity = "";
    private String strRegion = "";
    private String strZip = "";
    private String strCountry = "";
    private String strPhone = "";
    private String strExt = "";
    private String strError = "";

    Connection conn;
    Statement st;
    ResultSet rs;

    // constructor - customer id as parameter
    public employee(String em)
    {
        // load private variable
        strEmployeeID = em;

        // initialize database objects
        try
        {
            //initialize database driver
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

        // call method to get customer info from database
        // and load class variables
        getEmployeeInfo(em);
    }

    private void getEmployeeInfo(String em)
    {
        try
        {
            //create database connection
//            conn = DriverManager.getConnection(
//                    "jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
//            Connection conn = DriverManager.getConnection("jdbc:odbc:Northwind", "Admin", "");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            rs = st.executeQuery("SELECT * FROM employees WHERE EmployeeID = '" + em + "'");

            //loop to load class variables from result set
            while(rs.next())
            {
                strLastName = rs.getString("LastName");
                strFirstName = rs.getString("FirstName");
                strTitle = rs.getString("Title");
                strTitleCourtesy = rs.getString("TitleOfCourtesy");
                strAddress = rs.getString("Address");
                strCity = rs.getString("City");
                strRegion = rs.getString("Region");
                strZip = rs.getString("PostalCode");
                strCountry = rs.getString("Country");
                strPhone = rs.getString("HomePhone");
                strExt = rs.getString("Extension");
            }

            //close stuff
            rs.close();
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }

    }

    public String getLastName()
    {
        return strLastName;
    }
    public void setLastName(String ln)
    {
        strLastName = ln;
    }

    public String getFirstName()
    {
        return strFirstName;
    }
    public void setFirstName(String fn)
    {
        strFirstName = fn;
    }

    public String getTitle()
    {
        return strTitle;
    }
    public void setTitle(String t)
    {
        strTitle = t;
    }
    
    public String getTitleOfCourtesy(){
        return strTitleCourtesy;
    }
    
    public void setTitleOfCourtesy(String tc){
        strTitleCourtesy = tc;
    }

    public String getAddress()
    {
        return strAddress;
    }
    public void setAddress(String a)
    {
        strAddress = a;
    }

    public String getCity()
    {
        return strCity;
    }
    public void setCity(String c)
    {
        strCity = c;
    }

    public String getRegion()
    {
        return strRegion;
    }
    
    public void setRegion(String r)
    {
        strRegion = r;
    }

    public String getZip()
    {
        return strZip;
    }
    public void setZip(String z)
    {
        strZip = z;
    }

    public String getPhone()
    {
        return strPhone;
    }
    public void setPhone(String p)
    {
        strPhone = p;
    }
    public String getExt(){
        return strExt;
    }
    public void setExt(String ex){
        strExt = ex;
    }
    public String getCountry(){
        return strCountry;
    }
    public void setCountry(String ct){
        strCountry = ct;
    }
    public String getError(){
        return strError;
    }
    public void setError(String er){
        strError = er;
    }
    
    public boolean isError(){
        if(strError.length() > 0){
            return true;
        }else{
            return false;
        }
    }
    
     public void updateEmployeeInfo()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("UPDATE Employees " +
                    "SET LastName = \"" + getLastName() + "\", " +
                    "FirstName = '" + getFirstName() + "', " +
                    "Title = '" + getTitle() + "', " +
                    "TitleOfCourtesy = \"" + getTitleOfCourtesy() + "\", " +
                    "Address = '" + getAddress() + "', " +
                    "City = '" + getCity() + "', " +
                    "Region = '" + getRegion()+ "', " +
                    "PostalCode = '" + getZip() + "', " +
                    "Country = '" + getCountry() + "', " +
                    "HomePhone = '" + getPhone() + "', " +
                    "Extension = '" + getExt() + "' " +
                    "WHERE EmployeeID = '" + strEmployeeID + "'");

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     public void insertNewEmployee()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("INSERT INTO Employees(EmployeeID) " +
                    "VALUES(" + strEmployeeID  + ")" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }
     public void deleteEmployee()
    {
        try
        {
            //create database connection
            //conn = DriverManager.getConnection("jdbc:sqlserver://10.10.0.26;databaseName=Northwind;user=student;password=student");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind2", "root", "lati");

            //create statement object
            st = conn.createStatement();

            //create result set (executes SQL)
            st.executeUpdate("DELETE FROM Employees " +
                    "WHERE EmployeeID = '" + strEmployeeID  + "'" );

            //close stuff
            st.close();
            conn.close();
        }
        catch (Exception e)
        {
            setError(e.toString());
            System.out.println(e.toString());
        }
    }

}
